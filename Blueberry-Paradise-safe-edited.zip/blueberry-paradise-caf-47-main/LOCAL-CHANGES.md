# Local source-safety changes

This archive was updated without changing Lovable-managed database files or generated files.

- Removed the local `.env` file so environment values are not distributed in the source archive.
- Added `.env` and `.env.*` ignore rules while allowing the placeholder `.env.example`.
- Added `.env.example` containing variable names only; it has no credential values.

## Not changed

- `drizzle/` and `supabase/migrations/` (Lovable-managed database schema/migrations)
- files marked as automatically generated
- application pricing, catalog content, authentication, or checkout behaviour
- published Git history, Lovable project, database, storage, and deployment settings

## Verification

- ZIP archive integrity checked after packaging.
- Confirmed `.env` is absent and `.env.example` contains empty placeholders only.
- Automated tests and production build were not run in this environment because dependencies were not installed.
